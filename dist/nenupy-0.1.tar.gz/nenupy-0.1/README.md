# nenupy
Description of *nenupy*

# Installation
## pip
Description on how to install *nenupy*

## Package dependency
List of all required packages